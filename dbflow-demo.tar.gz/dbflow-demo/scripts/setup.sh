#!/usr/bin/env bash
# dbFlow Demo — Setup and Run Script
# =====================================
# Run this on any Mac/Linux machine with Python 3.11+ and Ollama installed.
# Total setup time from zero: ~25 minutes (mostly model download).
#
# Usage:
#   chmod +x scripts/setup.sh
#   ./scripts/setup.sh

set -e
GREEN='\033[0;32m'
AMBER='\033[0;33m'
RESET='\033[0m'

echo -e "${GREEN}dbFlow Demo Setup${RESET}"
echo "=================================="

# 1. Check Python version
python_version=$(python3 --version 2>&1 | awk '{print $2}')
echo "Python: $python_version"

# 2. Create virtual environment
if [ ! -d ".venv" ]; then
    echo -e "\n${AMBER}Creating virtual environment...${RESET}"
    python3 -m venv .venv
fi
source .venv/bin/activate

# 3. Install dependencies
echo -e "\n${AMBER}Installing Python dependencies...${RESET}"
pip install -q --upgrade pip
pip install -q -r requirements.txt

# 4. Check Ollama
echo -e "\n${AMBER}Checking Ollama...${RESET}"
if ! command -v ollama &> /dev/null; then
    echo "Ollama not found. Install from https://ollama.com/download"
    echo "Then run: ollama pull gemma2:9b"
    exit 1
fi

# 5. Pull Gemma 2 9B if not present
if ! ollama list | grep -q "gemma2:9b"; then
    echo -e "\n${AMBER}Pulling Gemma 2 9B (5.5GB — takes ~10 minutes)...${RESET}"
    ollama pull gemma2:9b
else
    echo "Gemma 2 9B: already downloaded"
fi

# 6. Start Ollama in background if not running
if ! curl -s http://localhost:11434/api/tags > /dev/null 2>&1; then
    echo -e "\n${AMBER}Starting Ollama server...${RESET}"
    ollama serve &
    sleep 3
fi

echo -e "\n${GREEN}Setup complete.${RESET}"
echo ""
echo "Start the demo with:"
echo "  source .venv/bin/activate"
echo "  uvicorn app.main:app --reload --port 8000"
echo ""
echo "Then open: http://localhost:8000"
echo ""
echo "API docs: http://localhost:8000/docs"
echo "Health:   http://localhost:8000/health"
