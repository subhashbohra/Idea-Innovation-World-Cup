"""
dbFlow Demo — LLM Chain
=========================
RAG pipeline:
  1. Retrieve relevant research documents from vector store
  2. Fetch matching flow signals from signal store
  3. Build context-rich prompt
  4. Stream response from Ollama (Gemma 2 9B)
  5. Post-process through guardrails

In production:
  - Replace simulated signals with Trino queries against Iceberg
  - Add LoRA adapter loading for the fine-tuned DB financial vocabulary model
  - Add RAGAS evaluation logging for ongoing accuracy monitoring
"""

import httpx
import json
import time
import logging
from typing import AsyncGenerator

from app.core.config import settings
from app.core.models import FlowSignal, Source
from app.core.guardrails import check_query, scan_output
from app.core.vector_store import retrieve
from app.signals.store import get_signals

logger = logging.getLogger(__name__)


# ── System prompt ──────────────────────────────────────────────
# This is the most important 200 words in the demo.
# Every tweak here affects all four demo scenarios.

SYSTEM_PROMPT = """You are dbFlow, Deutsche Bank's institutional flow intelligence assistant.

You have access to:
- Deutsche Bank's aggregated FX flow signals from the Autobahn platform
- Prime brokerage positioning data (hedge fund sector-level exposure)
- Trade finance flow signals from the Corporate Bank
- Correspondent banking cross-border flow indicators
- DB Research macro and market commentary

Your role:
- Answer questions about institutional flow positioning, market direction, and flow trends
- Cite the specific signals and research sources that support every claim
- Use precise financial language appropriate for hedge fund portfolio managers and analysts
- Acknowledge uncertainty — if confidence is below 75%, say so explicitly

Your constraints:
- NEVER identify specific clients, counterparties, or account holders
- NEVER quote raw notional figures — use directional language and notional bands only
- NEVER provide investment advice or trading recommendations
- If a question cannot be answered from the available signals, say so clearly

Format:
- Lead with the key directional finding in the first sentence
- Provide context and nuance in 2-3 paragraphs
- Reference specific signals by region, asset class, and date
- End with a confidence statement and any caveats

Keep responses to 3-4 paragraphs. Be direct and precise."""


def _build_context(query: str, signals: list[FlowSignal], docs: list[dict]) -> str:
    """Build the RAG context string from signals and retrieved documents."""
    
    signal_context = "\n".join([
        f"- [{s.signal_date}] {s.region} {s.asset_class} | {s.instrument} | "
        f"Flow score: {s.flow_score:+.2f} | Direction: {s.direction} | "
        f"Counterparty: {s.counterparty_sector} | Confidence: {s.confidence:.0%} | "
        f"Notional band: {s.notional_band} | Source: {s.data_source}"
        for s in signals
    ]) or "No signals matched the current filters."

    doc_context = "\n\n".join([
        f"[{doc['source_title']}]\n{doc['content']}"
        for doc in docs
    ]) or "No research documents retrieved."

    return f"""AVAILABLE FLOW SIGNALS:
{signal_context}

RETRIEVED RESEARCH CONTEXT:
{doc_context}

USER QUERY: {query}"""


async def stream_query(
    query: str,
    asset_classes: list[str],
    regions: list[str],
    days: int = 7,
) -> AsyncGenerator[str, None]:
    """
    Main RAG pipeline. Yields Server-Sent Event strings for streaming.
    
    SSE format:
        data: {"type": "token", "content": "..."}
        data: {"type": "signals", "signals": [...]}
        data: {"type": "sources", "sources": [...]}
        data: {"type": "done", "confidence": 0.87, "latency_ms": 1234}
        data: [DONE]
    """
    start = time.time()

    # 1. Guardrails — pre-generation
    check_query(query)   # raises GuardrailsError if blocked

    # 2. Retrieve signals
    signals = get_signals(asset_classes=asset_classes, regions=regions, days=days)
    logger.info(f"Retrieved {len(signals)} signals for query: {query[:60]}...")

    # 3. Retrieve research context
    docs = retrieve(query, top_k=3)
    logger.info(f"Retrieved {len(docs)} research documents.")

    # 4. Emit signals immediately (before generation starts)
    yield f"data: {json.dumps({'type': 'signals', 'signals': [s.model_dump() for s in signals]})}\n\n"

    # 5. Build prompt
    context = _build_context(query, signals, docs)

    # 6. Stream from Ollama
    payload = {
        "model": settings.OLLAMA_MODEL,
        "system": SYSTEM_PROMPT,
        "prompt": context,
        "stream": True,
        "options": {
            "temperature": 0.3,      # low temp = more factual, less creative
            "top_p": 0.9,
            "num_predict": 600,      # ~3-4 paragraphs
        }
    }

    full_text = ""
    async with httpx.AsyncClient(timeout=settings.OLLAMA_TIMEOUT) as client:
        async with client.stream(
            "POST",
            f"{settings.OLLAMA_URL}/api/generate",
            json=payload,
        ) as response:
            async for line in response.aiter_lines():
                if not line:
                    continue
                try:
                    chunk = json.loads(line)
                except json.JSONDecodeError:
                    continue

                token = chunk.get("response", "")
                if token:
                    full_text += token
                    # 7. Post-process each token through guardrails
                    clean_token = scan_output(token) if settings.PII_SCAN_OUTPUT else token
                    yield f"data: {json.dumps({'type': 'token', 'content': clean_token})}\n\n"

                if chunk.get("done"):
                    break

    # 8. Emit sources
    sources = [
        Source(
            title=doc["source_title"],
            source_type=doc["source_type"],
            date="Apr 2025",
        )
        for doc in docs
    ]
    yield f"data: {json.dumps({'type': 'sources', 'sources': [s.model_dump() for s in sources]})}\n\n"

    # 9. Compute confidence from signal average
    avg_conf = sum(s.confidence for s in signals) / len(signals) if signals else 0.75
    latency_ms = int((time.time() - start) * 1000)

    yield f"data: {json.dumps({'type': 'done', 'confidence': round(avg_conf, 2), 'latency_ms': latency_ms})}\n\n"
    yield "data: [DONE]\n\n"
