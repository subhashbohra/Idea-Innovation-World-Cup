"""
dbFlow Demo — Signals API Router
==================================
GET /v1/signals/live   → current live signal summary (sidebar cards)
GET /v1/signals/latest → latest N signals across all asset classes
"""

from fastapi import APIRouter
from app.signals.store import get_signals

router = APIRouter()


@router.get("/live")
async def live_signals():
    """
    Returns the four headline signals shown in the sidebar.
    In production: this is a cached Trino query refreshed every 5 minutes.
    """
    signals = get_signals(
        asset_classes=["FX", "CREDIT", "TRADE_FINANCE", "CORRESPONDENT"],
        regions=["EMEA", "APAC", "Americas"],
        days=1,
    )
    return {
        "signals": [s.model_dump() for s in signals[:4]],
        "as_of": "2025-04-28T16:00:00Z",
        "source": "Autobahn FX · Prime brokerage · Trade finance · Correspondent banking",
    }


@router.get("/latest")
async def latest_signals(
    asset_class: str = None,
    region: str = None,
    days: int = 7,
):
    """Full signal table for the given filters."""
    asset_classes = [asset_class] if asset_class else ["FX", "CREDIT", "RATES", "TRADE_FINANCE"]
    regions = [region] if region else ["EMEA", "APAC", "Americas"]
    signals = get_signals(asset_classes=asset_classes, regions=regions, days=days)
    return {"signals": [s.model_dump() for s in signals], "count": len(signals)}
