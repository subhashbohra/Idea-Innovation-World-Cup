"""dbFlow Demo — Health check"""
from fastapi import APIRouter
import httpx
from app.core.config import settings

router = APIRouter()


@router.get("/")
async def health():
    """Checks Ollama connectivity. Used by the demo setup script."""
    ollama_ok = False
    try:
        async with httpx.AsyncClient(timeout=3) as c:
            r = await c.get(f"{settings.OLLAMA_URL}/api/tags")
            ollama_ok = r.status_code == 200
    except Exception:
        pass

    return {
        "status": "ok" if ollama_ok else "degraded",
        "ollama": "connected" if ollama_ok else "unreachable",
        "model": settings.OLLAMA_MODEL,
        "demo_mode": settings.DEMO_MODE,
        "vector_store": settings.VECTOR_STORE,
    }
