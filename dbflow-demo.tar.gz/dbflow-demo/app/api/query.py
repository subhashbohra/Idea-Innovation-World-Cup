"""
dbFlow Demo — Query API Router
================================
POST /v1/query/stream  → Server-Sent Events (streaming)
POST /v1/query         → Full response (non-streaming, for SDK)
"""

from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse
import logging

from app.core.models import QueryRequest, QueryResponse
from app.core.guardrails import GuardrailsError
from app.llm.chain import stream_query

router = APIRouter()
logger = logging.getLogger(__name__)


@router.post("/stream")
async def query_stream(req: QueryRequest):
    """
    Streaming endpoint. Returns Server-Sent Events.
    
    The frontend connects to this with EventSource and renders
    tokens as they arrive — giving the live typing effect.
    
    Event types emitted:
        signals  — flow signal rows (emitted first, before generation)
        token    — individual generation token
        sources  — research source citations
        done     — confidence + latency metadata
        [DONE]   — stream terminated
    """
    try:
        return StreamingResponse(
            stream_query(
                query=req.query,
                asset_classes=req.asset_classes,
                regions=req.regions,
                days=req.date_range_days,
            ),
            media_type="text/event-stream",
            headers={
                "Cache-Control": "no-cache",
                "X-Accel-Buffering": "no",    # disable nginx buffering
            }
        )
    except GuardrailsError as e:
        raise HTTPException(
            status_code=400,
            detail={"error": "query_blocked", "reason": e.reason}
        )
    except Exception as e:
        logger.exception(f"Query error: {e}")
        raise HTTPException(status_code=500, detail="Internal inference error.")
