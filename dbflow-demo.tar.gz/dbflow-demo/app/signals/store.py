"""
dbFlow Demo — Simulated Signal Store
======================================
Generates realistic flow signals for the demo without needing
a real Iceberg/Trino connection.

In production: replace simulate_signals() with the Trino query
against the real Iceberg feature store tables.

Production Trino query (example):
    SELECT
        signal_date,
        asset_class,
        region,
        instrument,
        counterparty_sector,
        direction,
        notional_band,
        flow_score,
        confidence,
        data_source
    FROM nessie.dbflow_signals.fx_flows
    WHERE signal_date >= CURRENT_DATE - INTERVAL '7' DAY
      AND region IN ('EMEA', 'APAC')
    ORDER BY signal_date DESC, ABS(flow_score) DESC
    LIMIT 20;
"""

from datetime import date, timedelta
import random
from app.core.models import FlowSignal


def get_signals(
    asset_classes: list[str],
    regions: list[str],
    days: int = 7,
) -> list[FlowSignal]:
    """
    Returns simulated flow signals matching the query filters.
    Called by the query router to populate the response signals section.
    """
    # Pre-defined demo signals — realistic, internally consistent
    ALL_SIGNALS = [
        FlowSignal(
            signal_date="2025-04-28",
            asset_class="FX",
            region="EMEA",
            instrument="EM FX Basket",
            counterparty_sector="REAL_MONEY",
            direction="NET_SELL",
            notional_band="LARGE",
            flow_score=-0.61,
            confidence=0.87,
            data_source="nessie.dbflow_signals.fx_flows",
        ),
        FlowSignal(
            signal_date="2025-04-28",
            asset_class="FX",
            region="EMEA",
            instrument="TRY/USD",
            counterparty_sector="ALL",
            direction="NET_SELL",
            notional_band="LARGE",
            flow_score=-0.72,
            confidence=0.91,
            data_source="nessie.dbflow_signals.fx_flows",
        ),
        FlowSignal(
            signal_date="2025-04-28",
            asset_class="FX",
            region="APAC",
            instrument="USD/CNH",
            counterparty_sector="REAL_MONEY",
            direction="NET_SELL",
            notional_band="LARGE",
            flow_score=-0.45,
            confidence=0.78,
            data_source="nessie.dbflow_signals.fx_flows",
        ),
        FlowSignal(
            signal_date="2025-04-28",
            asset_class="CREDIT",
            region="EMEA",
            instrument="EUR IG Credit",
            counterparty_sector="HEDGE_FUND",
            direction="NET_BUY",
            notional_band="MEDIUM",
            flow_score=+0.38,
            confidence=0.83,
            data_source="nessie.dbflow_signals.prime_brokerage",
        ),
        FlowSignal(
            signal_date="2025-04-28",
            asset_class="CREDIT",
            region="EMEA",
            instrument="EUR HY Credit",
            counterparty_sector="HEDGE_FUND",
            direction="NEUTRAL",
            notional_band="MEDIUM",
            flow_score=-0.08,
            confidence=0.71,
            data_source="nessie.dbflow_signals.prime_brokerage",
        ),
        FlowSignal(
            signal_date="2025-04-27",
            asset_class="CREDIT",
            region="EMEA",
            instrument="Financials IG",
            counterparty_sector="HEDGE_FUND",
            direction="NET_BUY",
            notional_band="MEDIUM",
            flow_score=+0.51,
            confidence=0.88,
            data_source="nessie.dbflow_signals.prime_brokerage",
        ),
        FlowSignal(
            signal_date="2025-04-27",
            asset_class="TRADE_FINANCE",
            region="APAC",
            instrument="SCF volumes",
            counterparty_sector="CORPORATE",
            direction="NET_BUY",
            notional_band="LARGE",
            flow_score=+0.52,
            confidence=0.90,
            data_source="nessie.dbflow_signals.trade_finance",
        ),
        FlowSignal(
            signal_date="2025-04-27",
            asset_class="TRADE_FINANCE",
            region="APAC",
            instrument="LC issuance · Greater China",
            counterparty_sector="CORPORATE",
            direction="NEUTRAL",
            notional_band="LARGE",
            flow_score=-0.04,
            confidence=0.88,
            data_source="nessie.dbflow_signals.trade_finance",
        ),
        FlowSignal(
            signal_date="2025-04-27",
            asset_class="TRADE_FINANCE",
            region="APAC",
            instrument="LC exports · India",
            counterparty_sector="CORPORATE",
            direction="NET_BUY",
            notional_band="MEDIUM",
            flow_score=+0.61,
            confidence=0.85,
            data_source="nessie.dbflow_signals.trade_finance",
        ),
        FlowSignal(
            signal_date="2025-04-28",
            asset_class="CORRESPONDENT",
            region="APAC",
            instrument="USD inflow to China",
            counterparty_sector="ALL",
            direction="NET_SELL",
            notional_band="LARGE",
            flow_score=-0.33,
            confidence=0.81,
            data_source="nessie.dbflow_signals.correspondent",
        ),
    ]

    # Filter by requested asset classes and regions
    filtered = [
        s for s in ALL_SIGNALS
        if s.asset_class in asset_classes and s.region in regions
    ]

    # Sort by abs(flow_score) descending — most directional signals first
    filtered.sort(key=lambda s: abs(s.flow_score), reverse=True)
    return filtered[:8]
