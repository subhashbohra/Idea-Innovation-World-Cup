"""
dbFlow Demo — Guardrails Layer
================================
Pre-generation: query classifier
Post-generation: output PII and attribution scanner

This is non-negotiable for any external-facing product.
In production: replace regex with a fine-tuned classifier model.
"""

import re
import logging

logger = logging.getLogger(__name__)


# ── Blocked patterns ───────────────────────────────────────────

# Queries that try to extract client-identifiable information
BLOCKED_QUERY_PATTERNS = [
    r"\b(specific client|client name|account (number|id)|counterparty name)\b",
    r"\b(which (bank|fund|firm) (is|was) (buying|selling))\b",
    r"\b(exact (notional|volume|amount|size))\b",
    r"\b(who (bought|sold|traded))\b",
    r"\b(position of [A-Z][a-z]+ (fund|capital|asset|management))\b",
]

# Output patterns that would indicate PII or client attribution leaked through
BLOCKED_OUTPUT_PATTERNS = [
    r"\b[A-Z][a-z]+ (Capital|Asset Management|Fund|Partners|Investments) (bought|sold|holds)\b",
    r"\$[\d,]+\s*(million|billion|mn|bn)\b",          # raw notionals
    r"account (number|id)[:\s]+\w+",                   # account identifiers
    r"\b\d{10,}\b",                                    # long numeric IDs
]


class GuardrailsError(Exception):
    """Raised when a query or output fails the guardrails check."""
    def __init__(self, message: str, reason: str):
        super().__init__(message)
        self.reason = reason


def check_query(query: str) -> None:
    """
    Pre-generation check. Raises GuardrailsError if the query
    appears to be seeking client-attributable or prohibited information.
    """
    q_lower = query.lower()
    for pattern in BLOCKED_QUERY_PATTERNS:
        if re.search(pattern, q_lower, re.IGNORECASE):
            logger.warning(f"Query blocked by guardrails: pattern={pattern}")
            raise GuardrailsError(
                message="This query cannot be answered by dbFlow.",
                reason=(
                    "dbFlow provides aggregated, non-attributable flow signals only. "
                    "Queries seeking specific client identities, account details, "
                    "or exact position sizes are not supported."
                )
            )


def scan_output(text: str) -> str:
    """
    Post-generation scan. Removes or flags any output that contains
    patterns suggesting PII or client attribution leaked through generation.
    Returns cleaned text. Logs any redactions.
    """
    cleaned = text
    for pattern in BLOCKED_OUTPUT_PATTERNS:
        matches = re.findall(pattern, cleaned, re.IGNORECASE)
        if matches:
            logger.warning(f"Output redaction triggered: pattern={pattern}, matches={matches}")
            cleaned = re.sub(pattern, "[REDACTED]", cleaned, flags=re.IGNORECASE)
    return cleaned


def validate_flow_score(score: float) -> bool:
    """Flow scores must be in [-1.0, 1.0]. Hard clamp at boundaries."""
    return -1.0 <= score <= 1.0
