"""
dbFlow Demo — Vector Store
============================
In-memory vector store for the demo (no pgvector needed to run locally).
Embeds a small representative research corpus using sentence-transformers.

In production: replace with pgvector + HNSW index.
Schema:
    CREATE EXTENSION IF NOT EXISTS vector;
    CREATE TABLE dbflow.embeddings (
        id SERIAL PRIMARY KEY,
        content TEXT,
        source_type VARCHAR,
        source_title VARCHAR,
        source_date DATE,
        embedding vector(384)   -- all-MiniLM-L6-v2 dimension
    );
    CREATE INDEX ON dbflow.embeddings
        USING hnsw (embedding vector_cosine_ops)
        WITH (m=16, ef_construction=64);
"""

import logging
from typing import Optional
import json

logger = logging.getLogger(__name__)

# Global in-memory store
_store: list[dict] = []
_embedder = None


# ── Demo research corpus ───────────────────────────────────────
# In production: this is replaced by DB's actual research documents,
# macro commentary, and internal flow reports chunked at 512 tokens.

DEMO_CORPUS = [
    {
        "content": "Real money accounts have been systematically reducing EM FX exposure over the past three weeks. The selling is broad-based across EMEA EM currencies, with particular pressure in TRY, ZAR, and EGP. Autobahn FX flow data indicates large-notional selling concentrated in the European morning session, consistent with institutional rebalancing rather than tactical positioning.",
        "source_type": "flow_data",
        "source_title": "Autobahn FX Flow Monitor · EMEA · Apr 2025",
    },
    {
        "content": "Hedge fund net positioning in European Investment Grade credit has shifted from net short to net long over the past fortnight. The reversal is concentrated in financial and utilities sectors, where spreads have widened 18-22bp year to date. Multi-strategy funds account for the majority of the buying. High yield positioning remains flat, suggesting selective duration extension rather than broad risk-on rotation.",
        "source_type": "research",
        "source_title": "DB Credit Research: European IG Spread Monitor · Apr 2025",
    },
    {
        "content": "Asia Pacific trade finance flows in Q1 2025 show divergence between sub-regions. Supply chain finance volumes in Southeast Asia (Vietnam, Indonesia, Thailand) expanded materially, driven by manufacturing supply chain diversification. Greater China LC issuance is flat year on year. India LC export volumes are up approximately 18% year on year, reflecting expansion of goods export capacity.",
        "source_type": "flow_data",
        "source_title": "Corporate Bank Trade Finance Monitor · APAC · Q1 2025",
    },
    {
        "content": "USD/CNH positioning shows net selling of CNH, with the pressure building over 10 trading days. Real money accounts are the primary sellers. Hedge fund flow is mixed. Correspondent banking data cross-check: cross-border USD inflow to mainland China has declined relative to the 90-day average, typically a leading indicator of Real Money CNH selling pressure.",
        "source_type": "correspondent",
        "source_title": "DB Asia FX Research: CNH Positioning Tracker · Apr 2025",
    },
    {
        "content": "EM currency flows exhibit a classic risk-off pattern: real money selling is broad, hedge fund positioning is split between momentum shorts and value buyers, and corporate hedging flows are providing some support. The counterparty decomposition suggests this is portfolio rebalancing rather than a stress event. Confidence in the signal is high given representative sample from Autobahn FX across the EMEA session.",
        "source_type": "research",
        "source_title": "DB Macro Research: EM FX Positioning Monitor · Apr 2025",
    },
    {
        "content": "European credit markets: IG spreads have widened materially year to date versus US IG, creating relative value that institutional investors are beginning to exploit. The carry on EUR IG versus equivalent duration Bunds is at multi-year highs. Prime brokerage data confirms the positioning shift is institutional in nature — not retail or momentum-driven.",
        "source_type": "research",
        "source_title": "DB Research: Cross-Asset Flow Intelligence · Apr 2025",
    },
]


async def init_vector_store() -> None:
    """
    Initialise the in-memory vector store by embedding the demo corpus.
    Uses sentence-transformers all-MiniLM-L6-v2 (84MB, runs on CPU).
    Falls back to keyword matching if transformers not installed.
    """
    global _store, _embedder

    try:
        from sentence_transformers import SentenceTransformer
        logger.info("Loading sentence-transformers model (all-MiniLM-L6-v2)...")
        _embedder = SentenceTransformer("all-MiniLM-L6-v2")
        embeddings = _embedder.encode([d["content"] for d in DEMO_CORPUS])
        _store = [
            {**doc, "embedding": emb.tolist()}
            for doc, emb in zip(DEMO_CORPUS, embeddings)
        ]
        logger.info(f"Vector store initialised with {len(_store)} documents (embeddings).")
    except ImportError:
        logger.warning("sentence-transformers not installed — using keyword fallback retrieval.")
        _store = [{**doc, "embedding": None} for doc in DEMO_CORPUS]


def retrieve(query: str, top_k: int = 3) -> list[dict]:
    """
    Retrieve top-k most relevant documents for the query.
    Uses cosine similarity if embeddings available, else keyword overlap.
    """
    if not _store:
        return []

    if _embedder is not None and _store[0]["embedding"] is not None:
        return _retrieve_semantic(query, top_k)
    else:
        return _retrieve_keyword(query, top_k)


def _retrieve_semantic(query: str, top_k: int) -> list[dict]:
    """Cosine similarity retrieval using sentence-transformers."""
    import numpy as np
    q_emb = _embedder.encode([query])[0]
    scores = []
    for doc in _store:
        emb = np.array(doc["embedding"])
        score = float(np.dot(q_emb, emb) / (np.linalg.norm(q_emb) * np.linalg.norm(emb) + 1e-9))
        scores.append((score, doc))
    scores.sort(key=lambda x: x[0], reverse=True)
    return [doc for _, doc in scores[:top_k]]


def _retrieve_keyword(query: str, top_k: int) -> list[dict]:
    """Simple keyword overlap fallback."""
    q_words = set(query.lower().split())
    scores = []
    for doc in _store:
        d_words = set(doc["content"].lower().split())
        score = len(q_words & d_words)
        scores.append((score, doc))
    scores.sort(key=lambda x: x[0], reverse=True)
    return [doc for _, doc in scores[:top_k]]
