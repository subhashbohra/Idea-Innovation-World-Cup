"""
dbFlow Demo — Configuration
============================
All config in one place. Override via environment variables.
"""

from pydantic_settings import BaseSettings
from typing import Literal


class Settings(BaseSettings):
    # Ollama (local, air-gapped)
    OLLAMA_URL: str = "http://localhost:11434"
    OLLAMA_MODEL: str = "gemma2:9b"          # run: ollama pull gemma2:9b
    OLLAMA_TIMEOUT: int = 60

    # Demo mode — uses simulated signals instead of real Iceberg
    # Set to False when running against real data platform
    DEMO_MODE: bool = True

    # Vector store (pgvector or in-memory for demo)
    VECTOR_STORE: Literal["memory", "pgvector"] = "memory"
    PGVECTOR_URL: str = "postgresql://localhost:5432/dbflow"

    # API
    API_RATE_LIMIT: int = 100              # queries per day (Tier 1 equivalent)
    MAX_SIGNAL_ROWS: int = 20              # max rows returned per query

    # Guardrails
    ENABLE_GUARDRAILS: bool = True
    PII_SCAN_OUTPUT: bool = True

    # Trino (real data — not used in demo mode)
    TRINO_HOST: str = "localhost"
    TRINO_PORT: int = 8080
    TRINO_CATALOG: str = "nessie"
    TRINO_SCHEMA: str = "dbflow_signals"

    class Config:
        env_prefix = "DBFLOW_"
        env_file = ".env"


settings = Settings()
