"""
dbFlow Demo — Shared Data Models
==================================
Pydantic models for request/response contracts.
These are what the Python SDK will wrap.
"""

from pydantic import BaseModel, Field
from typing import Literal, Optional
from datetime import date


# ── Signal models ──────────────────────────────────────────────

class FlowSignal(BaseModel):
    signal_date: str
    asset_class: Literal["FX", "CREDIT", "RATES", "TRADE_FINANCE", "CORRESPONDENT"]
    region: Literal["EMEA", "APAC", "Americas", "Global"]
    instrument: str                          # e.g. "USD/EM Basket", "EUR IG Credit"
    counterparty_sector: Optional[Literal[
        "HEDGE_FUND", "REAL_MONEY", "CORPORATE", "OFFICIAL_SECTOR", "ALL"
    ]] = "ALL"
    direction: Literal["NET_BUY", "NET_SELL", "NEUTRAL"]
    notional_band: Literal["LARGE", "MEDIUM", "SMALL"]  # never raw notional
    flow_score: float = Field(..., ge=-1.0, le=1.0)     # -1.0 strong sell → +1.0 strong buy
    confidence: float = Field(..., ge=0.0, le=1.0)
    data_source: str                         # which approved source table
    notes: Optional[str] = None


class Source(BaseModel):
    title: str
    source_type: Literal["flow_data", "research", "correspondent"]
    date: str


# ── Query request ──────────────────────────────────────────────

class QueryRequest(BaseModel):
    query: str = Field(..., min_length=5, max_length=500)
    asset_classes: list[Literal["FX", "CREDIT", "RATES", "TRADE_FINANCE"]] = [
        "FX", "CREDIT", "RATES", "TRADE_FINANCE"
    ]
    regions: list[Literal["EMEA", "APAC", "Americas"]] = ["EMEA", "APAC", "Americas"]
    date_range_days: int = Field(default=7, ge=1, le=90)
    stream: bool = True


# ── Query response ─────────────────────────────────────────────

class QueryResponse(BaseModel):
    query: str
    narration: str
    signals: list[FlowSignal]
    sources: list[Source]
    confidence: float
    model: str
    latency_ms: int
    disclaimer: str = (
        "For informational purposes only. Not investment advice. "
        "Signals are aggregated and non-attributable. "
        "Deutsche Bank dbFlow — Innovation World Cup Demo."
    )
