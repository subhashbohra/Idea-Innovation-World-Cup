"""
dbFlow Demo — Main FastAPI Application
=======================================
Runs locally on port 8000.
Connects to Ollama running on localhost:11434.
Uses simulated Iceberg/flow signal data for the demo.

Start with:
    uvicorn app.main:app --reload --port 8000
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse
from contextlib import asynccontextmanager
import logging

from app.api.query import router as query_router
from app.api.signals import router as signals_router
from app.api.health import router as health_router
from app.core.config import settings
from app.core.vector_store import init_vector_store

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Startup: initialise vector store with demo research corpus."""
    logger.info("Initialising dbFlow demo...")
    await init_vector_store()
    logger.info(f"Vector store ready. Ollama endpoint: {settings.OLLAMA_URL}")
    yield
    logger.info("dbFlow demo shutting down.")


app = FastAPI(
    title="dbFlow Demo",
    description="Conversational flow intelligence platform — Innovation World Cup demo",
    version="0.1.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],   # demo only — lock down in production
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(health_router, prefix="/health", tags=["health"])
app.include_router(signals_router, prefix="/v1/signals", tags=["signals"])
app.include_router(query_router, prefix="/v1/query", tags=["query"])

# Serve the demo frontend
app.mount("/static", StaticFiles(directory="frontend"), name="static")


@app.get("/", response_class=HTMLResponse)
async def root():
    with open("frontend/index.html") as f:
        return f.read()
